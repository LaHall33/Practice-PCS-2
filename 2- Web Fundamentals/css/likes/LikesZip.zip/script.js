function addingUp(id) {
  
  const span = document.querySelector('#' + id);
    span.textContent++;
  }
